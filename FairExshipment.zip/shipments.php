<?php
require_once '../config.php';

session_start();

$conn = getDBConnection();

// Helper function to check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Helper function to generate tracking code
function generateTrackingCode($conn) {
    do {
        $code = 'TRK-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
        $stmt = $conn->prepare("SELECT id FROM shipments WHERE tracking_code = ?");
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
    } while ($result->num_rows > 0);
    
    return $code;
}

// GET - Retrieve shipment(s)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // Get single shipment by tracking code (public access)
    if (isset($_GET['tracking_code'])) {
        $tracking_code = $_GET['tracking_code'];
        
        $stmt = $conn->prepare("SELECT * FROM shipments WHERE tracking_code = ?");
        $stmt->bind_param("s", $tracking_code);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $shipment = $result->fetch_assoc();
            
            // Get timeline
            $timeline_stmt = $conn->prepare("SELECT * FROM tracking_timeline WHERE shipment_id = ? ORDER BY created_at ASC");
            $timeline_stmt->bind_param("i", $shipment['id']);
            $timeline_stmt->execute();
            $timeline_result = $timeline_stmt->get_result();
            
            $timeline = [];
            while ($row = $timeline_result->fetch_assoc()) {
                $timeline[] = [
                    'date' => $row['created_at'],
                    'status' => $row['status'],
                    'description' => $row['description']
                ];
            }
            
            $shipment['timeline'] = $timeline;
            
            echo json_encode(['success' => true, 'shipment' => $shipment]);
            $timeline_stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Shipment not found']);
        }
        
        $stmt->close();
    }
    // Get all shipments (admin only)
    else {
        if (!isAdminLoggedIn()) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }
        
        $result = $conn->query("SELECT * FROM shipments ORDER BY created_at DESC");
        $shipments = [];
        
        while ($row = $result->fetch_assoc()) {
            $shipments[] = $row;
        }
        
        echo json_encode(['success' => true, 'shipments' => $shipments]);
    }
}

// POST - Create new shipment (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isAdminLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $tracking_code = generateTrackingCode($conn);
    $client_name = $data['client_name'] ?? '';
    $client_email = $data['client_email'] ?? null;
    $client_phone = $data['client_phone'] ?? null;
    $status = $data['status'] ?? 'pending';
    $origin = $data['origin'] ?? '';
    $destination = $data['destination'] ?? '';
    $description = $data['description'] ?? null;
    $weight = $data['weight'] ?? null;
    $estimated_delivery = $data['estimated_delivery'] ?? null;
    
    if (empty($client_name) || empty($origin) || empty($destination)) {
        echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
        exit;
    }
    
    // Insert shipment
    $stmt = $conn->prepare("INSERT INTO shipments (tracking_code, client_name, client_email, client_phone, status, origin, destination, description, weight, estimated_delivery) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssds", $tracking_code, $client_name, $client_email, $client_phone, $status, $origin, $destination, $description, $weight, $estimated_delivery);
    
    if ($stmt->execute()) {
        $shipment_id = $stmt->insert_id;
        
        // Add initial timeline entry
        $timeline_stmt = $conn->prepare("INSERT INTO tracking_timeline (shipment_id, status, description) VALUES (?, 'created', 'Shipment created and awaiting pickup')");
        $timeline_stmt->bind_param("i", $shipment_id);
        $timeline_stmt->execute();
        $timeline_stmt->close();
        
        echo json_encode([
            'success' => true,
            'message' => 'Shipment created successfully',
            'tracking_code' => $tracking_code,
            'shipment_id' => $shipment_id
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create shipment']);
    }
    
    $stmt->close();
}

// PUT - Update shipment (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    if (!isAdminLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $shipment_id = $data['id'] ?? 0;
    $status = $data['status'] ?? null;
    $timeline_description = $data['timeline_description'] ?? null;
    
    if ($shipment_id && $status && $timeline_description) {
        // Update shipment status
        $stmt = $conn->prepare("UPDATE shipments SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $shipment_id);
        
        if ($stmt->execute()) {
            // Add timeline entry
            $timeline_stmt = $conn->prepare("INSERT INTO tracking_timeline (shipment_id, status, description) VALUES (?, ?, ?)");
            $timeline_stmt->bind_param("iss", $shipment_id, $status, $timeline_description);
            $timeline_stmt->execute();
            $timeline_stmt->close();
            
            echo json_encode(['success' => true, 'message' => 'Shipment updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update shipment']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid data provided']);
    }
}

// DELETE - Delete shipment (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    if (!isAdminLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    $shipment_id = $data['id'] ?? 0;
    
    if ($shipment_id) {
        $stmt = $conn->prepare("DELETE FROM shipments WHERE id = ?");
        $stmt->bind_param("i", $shipment_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Shipment deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete shipment']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid shipment ID']);
    }
}

$conn->close();
?>
