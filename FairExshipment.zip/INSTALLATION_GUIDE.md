# Shipment Tracking System - Installation Guide

## 📋 Prerequisites
- Web hosting with PHP 7.4+ and MySQL 5.7+
- Domain name configured
- FTP/cPanel access to your hosting

## 🚀 Installation Steps

### Step 1: Upload Files to Your Hosting

Upload these files to your hosting (usually in `public_html` or `www` directory):
```
├── index.html          (Main website file)
├── .htaccess          (Apache configuration)
├── config.php         (Database configuration - IMPORTANT!)
├── database.sql       (Database schema)
└── api/
    ├── login.php      (Login API)
    ├── logout.php     (Logout API)
    └── shipments.php  (Shipment management API)
```

### Step 2: Create MySQL Database

1. **Login to cPanel or phpMyAdmin**
2. **Create a new database:**
   - Database name: `shipment_tracker`
   - Create a database user with a strong password
   - Grant ALL privileges to this user for the database

3. **Import the database schema:**
   - Open phpMyAdmin
   - Select your `shipment_tracker` database
   - Click "Import" tab
   - Upload the `database.sql` file
   - Click "Go"

### Step 3: Configure Database Connection

1. **Open `config.php` file**
2. **Update the following values:**

```php
define('DB_HOST', 'localhost');              // Usually 'localhost'
define('DB_USER', 'your_mysql_username');    // Your MySQL username
define('DB_PASS', 'your_mysql_password');    // Your MySQL password
define('DB_NAME', 'shipment_tracker');       // Database name
```

**Example:**
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'mysite_dbuser');
define('DB_PASS', 'SecurePass123!');
define('DB_NAME', 'shipment_tracker');
```

### Step 4: Update API URL (if needed)

1. **Open `index.html`**
2. **Find this line near the top of the `<script>` section:**

```javascript
const API_URL = 'api';
```

3. **Update based on your setup:**
   - If files are in root: `const API_URL = 'api';` ✅ (default)
   - If in subdirectory: `const API_URL = '/subfolder/api';`
   - Full domain: `const API_URL = 'https://yourdomain.com/api';`

### Step 5: Set Folder Permissions

Ensure proper permissions (using FTP or cPanel File Manager):
- `api/` folder: 755
- All `.php` files: 644
- `index.html`: 644
- `.htaccess`: 644

### Step 6: Test Your Installation

1. **Visit your website:** `https://yourdomain.com`
2. **Test customer tracking:**
   - You won't have any shipments yet
   - Try entering a fake code to verify the "not found" message works

3. **Test admin login:**
   - Click "Admin Panel"
   - Login with:
     - Email: `admin@fx.com`
     - Password: `admin123`

4. **Create a test shipment:**
   - Fill in all required fields
   - Click "Create Shipment"
   - Note the tracking code

5. **Test tracking:**
   - Switch to "Track Shipment"
   - Enter the tracking code
   - Verify all details appear correctly

## 🔒 Security Recommendations

### 1. Change Admin Password
After installation, update the admin password in the database:

```sql
UPDATE admins SET password = 'YourNewPassword123!' WHERE email = 'admin@fx.com';
```

**Better yet**, implement password hashing:
1. In `api/login.php`, replace password comparison with:
```php
if (password_verify($password, $admin['password'])) {
```

2. Hash passwords in database:
```php
$hashed = password_hash('admin123', PASSWORD_DEFAULT);
// Update database with $hashed
```

### 2. Secure config.php
The `.htaccess` file already denies direct access, but also:
- Place `config.php` outside the public web directory if possible
- Use strong database passwords

### 3. Enable HTTPS
- Get an SSL certificate (free with Let's Encrypt)
- Force HTTPS in `.htaccess`:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 4. Disable Error Display in Production
In `config.php`, comment out these lines:
```php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
```

## 🐛 Troubleshooting

### Database Connection Error
- Verify credentials in `config.php`
- Check if MySQL user has correct permissions
- Confirm database name is correct
- Try connecting via phpMyAdmin with same credentials

### API Not Working / 404 Errors
- Check if `.htaccess` is uploaded and active
- Verify mod_rewrite is enabled on your hosting
- Check API_URL in `index.html` matches your folder structure
- Look at browser console (F12) for error messages

### Login Not Working
- Clear browser cache and cookies
- Check browser console for errors
- Verify `api/login.php` file was uploaded
- Test API directly: `yourdomain.com/api/login.php`

### Tracking Code Not Found
- Verify shipment was created successfully
- Check database table `shipments` has records
- Tracking codes are case-sensitive (uppercase)

## 📊 Database Structure

### admins table
- `id`: Primary key
- `email`: Admin email (unique)
- `password`: Admin password
- `created_at`: Account creation timestamp

### shipments table
- `id`: Primary key
- `tracking_code`: Unique tracking code (e.g., TRK-ABC123)
- `client_name`: Customer name
- `client_email`: Customer email
- `client_phone`: Customer phone
- `status`: pending | in-transit | delivered
- `origin`: Shipment origin location
- `destination`: Destination location
- `description`: Package description
- `weight`: Package weight in kg
- `estimated_delivery`: Expected delivery date
- `created_at`: Creation timestamp
- `updated_at`: Last update timestamp

### tracking_timeline table
- `id`: Primary key
- `shipment_id`: Foreign key to shipments
- `status`: Status type
- `description`: Status description
- `created_at`: Timestamp

## 🎯 Features

✅ Admin login with session management
✅ Create unlimited shipments with auto-generated tracking codes
✅ Real-time shipment tracking for customers
✅ Timeline/history for each shipment
✅ Responsive design (works on mobile)
✅ MySQL database for data persistence
✅ Secure API endpoints

## 📞 Support

If you encounter issues:
1. Check browser console (F12 → Console tab)
2. Check PHP error logs in cPanel
3. Verify all files were uploaded correctly
4. Test database connection in phpMyAdmin

## 🔄 Backup

Regular backups are recommended:
1. **Database:** Export via phpMyAdmin
2. **Files:** Download all files via FTP

---

**Default Admin Credentials:**
- Email: admin@fx.com
- Password: admin123

**⚠️ IMPORTANT: Change the admin password immediately after installation!**
